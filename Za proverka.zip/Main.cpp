#include "String.h"
int main()
{
	String test1, test2;
	test1.print();
	std::cout << std::endl;
	test1.setString("Proba");
	//test1.add('5');
	test1.insertAt('6', 3);
	test1.removeAt(1);
	test1.print();
	/*std::cout << std::endl;
	test2.setString("Hey");
	test1 = test2;
	test1.print();
	std::cout << std::endl;
	test1.insertAt('3', 1);
	test1.print();*/
	return 0;
}